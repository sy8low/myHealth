.. myHealth documentation master file, created by
   sphinx-quickstart on Mon May 27 12:58:37 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to myHealth's documentation!
====================================
.. automodule:: src.myHealth
   :members:

.. automodule:: src.myHealth.myHealth
   :members:

.. automodule:: src.myHealth.medication
   :members:

.. automodule:: src.myHealth.vitals
   :members:

.. automodule:: src.myHealth.utility
   :members:

.. automodule:: src.myHealth.visualisation
   :members:

.. toctree::
   :maxdepth: 2
   :caption: Contents:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
